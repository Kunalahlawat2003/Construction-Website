const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const path = require('path');
const cors = require('cors');
const https = require('https');
const fs = require('fs');

const app = express();
const port = process.env.PORT || 443;



// Connect to MongoDB (replace 'your-mongodb-uri' with your actual MongoDB connection string)
mongoose.connect('mongodb+srv://ahlawatkunal21:Kunal2409@kunal.7wvpdgi.mongodb.net/', { useNewUrlParser: true, useUnifiedTopology: true });

// Define a schema for the quotes
const quoteSchema = new mongoose.Schema({
  selectedmachinery: String,
  modelist: mongoose.Schema.Types.Mixed,
  quantity: String,
  name: String,
  email: String,
  phone: String,
  company: String,
  message: String,
});

// Create a model based on the schema
const Quote = mongoose.model('Quote', quoteSchema);

// Parse URL-encoded bodies (as sent by HTML forms)
app.use(express.json());

app.use(cors());

// Serve static files (like HTML, CSS, and JavaScript)
app.use(express.static(__dirname));

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

// Handle form submission
app.post('/quote', async (req, res) => {
  // db.kunal.update({}, { $rename: { "selectedMachinery": "selectedmachinery" } }, { multi: true })
  console.log('Received request:',req.body);
  const {
    selectedmachinery,
    modelist,
    quantity,
    name, 
    email,
    phone,
    company,
    message,
  } = req.body;



  // Create a new quote instance
  const newQuote = new Quote({
    selectedmachinery,
    modelist,
    quantity,
    name,
    email,
    phone,
    company,
    message,
  });

  // Save the quote to the database
  try {
    await newQuote.save();
    console.log('Quote saved successfully');
    res.json({ success: true });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, error: 'Error saving quote to the database' });
  }
});


const privateKey = fs.readFileSync('path/to/private-key.pem', 'utf8');
const certificate = fs.readFileSync('path/to/certificate.pem', 'utf8');

const credentials = { key: privateKey, cert: certificate};

// Start the server
const server = https.createServer(credentials, app);

server.listen(port, () => {
  console.log(`Server is running at https://localhost:${port}`);
});