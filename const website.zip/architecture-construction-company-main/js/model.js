document.addEventListener("DOMContentLoaded", function() {
    // Trigger the updatemodelist function on page load
    updatemodelist();

    // Attach the updatemodelist function to the change event of the selectedmachinery element
    document.getElementById("selectedmachinery").addEventListener("change", updatemodelist);
});
function updatemodelist() {
    // Get the selected value from the first listbox
    var selectedmachinery = document.getElementById("selectedmachinery").value;

    // Get the second listbox element
    var modelist = document.getElementById("modelist");

    // Clear existing options in the second listbox
    modelist.innerHTML = "";

    // Add new options based on the selection in the first listbox
    if (selectedmachinery === "Tata Tipper Truck") {
      addOption(modelist, "TATA LKP2518CR", "TATA LKP2518CR");
      addOption(modelist, "TATA SIGNA 2825K", "TATA SIGNA 2825K");
      addOption(modelist, "TATA 2518", "TATA 2518");
    } else if (selectedmachinery === "Mahindra Tipper Truck") {
      addOption(modelist, "TORRO 25/16", "TORRO 25/16");
    } else if (selectedmachinery === "Ashok Leyland Tipper Truck") {
      addOption(modelist, "UE2825T", "UE2825T");
    } else if (selectedmachinery === "Tata Mixer") {
        addOption(modelist, "TATA SIGNA 2823K", "TATA SIGNA 2823K");
        addOption(modelist, "TATA 2518 TC 6X4", "TATA 2518 TC 6X4");
   }  else if (selectedmachinery === "Ashok Leyland Shifting Trailor") {
    addOption(modelist, "Ashok Leyland 5525", "Ashok Leyland 5525");
    addOption(modelist, "Ashok Leyland 35.16", "Ashok Leyland 35.16");
   }   else if (selectedmachinery === "Tata Water Tanker") {
    addOption(modelist, "Tata Water Tanker 25.16", "Tata Water Tanker 25.16");
    addOption(modelist, "Tata Water Tanker 25.18", "Tata Water Tanker 25.18");
   }  
       else if (selectedmachinery === "Tata Transit Trailer") {
       addOption(modelist, "Tata 5525.S", "Tata 5525.S");
   }   else if (selectedmachinery === "Tata Diesel Tanker") {
    addOption(modelist, "Tata SF 510", "Tata SF 510");
    addOption(modelist, "Tata SF 710", "Tata SF 710");
   }   else if (selectedmachinery === "Ashok Leyland Diesel Tanker") {
    addOption(modelist, "Ashok Leyland", "Ashok Leyland");
   }   else if (selectedmachinery === "Mahindra Camper") {
    addOption(modelist, "Bolero Camper ZX Gold", "Bolero Camper ZX Gold");
    addOption(modelist, "Bolero Seven Seater", "Bolero Seven Seater");
    addOption(modelist, "Bolero Pickup FB PS 1.7T", "Bolero Pickup FB PS 1.7T");
   }   else if (selectedmachinery === "Hero Motor Bike") {
    addOption(modelist, "HF Deluxe", "HF Deluxe");
   }   else if (selectedmachinery === "Honda Motor Bike") {
    addOption(modelist, "CD Deluxe", "CD Deluxe");
   }   else if (selectedmachinery === "Bajaj Motor Bike") {
    addOption(modelist, "Bajaj Discover", "Bajaj Discover");
   }   else if (selectedmachinery === "Tractor Broomer") {
    addOption(modelist, "Heavy Duty", "Heavy Duty");
   }   else if (selectedmachinery === "Tractor Dewatering") {
    addOption(modelist, "6 Inch", "6 Inch");
   }   else if (selectedmachinery === "Tractor Holland") {
    addOption(modelist, "7500", "7500");
    addOption(modelist, "3630", "3630");
   }   else if (selectedmachinery === "JCB Wheel Loader") {
    addOption(modelist, "437-4", "437-4");
   }   else if (selectedmachinery === "Backhoe Loader") {
    addOption(modelist, "JCB 3DX", "JCB 3DX");
   }   else if (selectedmachinery === "Liugong Wheel Loader") {
    addOption(modelist, "CLG888", "CLG888");
    addOption(modelist, "CLG835", "CLG835");
   }   else if (selectedmachinery === "Wirtgen Roller") {
    addOption(modelist, "Tandem", "Tandem");
   }   else if (selectedmachinery === "Wirtgen Soil Compactor") {
    addOption(modelist, "Hamm 311", "Hamm 311");
   }   else if (selectedmachinery === "CAT Grader") {
    addOption(modelist, "120K2/120NG", "120K2/120NG");
   }   else if (selectedmachinery === "Mahindra Grader") {
    addOption(modelist, "G75", "G75");
   }   else if (selectedmachinery === "CAT Excavator") {
    addOption(modelist, "320C", "320C");
    addOption(modelist, "320D", "320D");
   }   else if (selectedmachinery === "Komatsu Excavator") {
    addOption(modelist, "PC-300", "PC-300");
    addOption(modelist, "PC-200", "PC-200");
    addOption(modelist, "PC-210LC", "PC-210LC");
   }   else if (selectedmachinery === "Volvo Excavator") {
    addOption(modelist, "290LC", "290LC");
   }   else if (selectedmachinery === "L&T Excavator") {
    addOption(modelist, "PC-136", "PC-136");
   }   else if (selectedmachinery === "Kobelco Excavator") {
    addOption(modelist, "SK220", "SK220");
   }   else if (selectedmachinery === "Tata Hitachi Excavator") {
    addOption(modelist, "ZX220", "ZX220");
   }   else if (selectedmachinery === "Escorts Crane") {
    addOption(modelist, "14 TON", "14 TON");
   }   else if (selectedmachinery === "Metsu Stone Crusher") {
    addOption(modelist, "GP-220", "GP-220");
   }   else if (selectedmachinery === "Puzzolana Stone Crusher") {
    addOption(modelist, "250-TPH", "250-TPH");
   }   else if (selectedmachinery === "Aquarious Batching Plant") {
    addOption(modelist, "SP-120", "SP-120");
   }   else if (selectedmachinery === "Conmet Batching Plant") {
    addOption(modelist, "CP-750", "CP-750");
    addOption(modelist, "CP-60", "CP-60");
   }   else if (selectedmachinery === "Liebherr Batching Plant") {
    addOption(modelist, "M1", "M1");
   }   else if (selectedmachinery === "Schwing Stetter Batching Plant") {
    addOption(modelist, "CP-30", "CP-30");
   }   else if (selectedmachinery === "Everest Hot Mix Plant") {
    addOption(modelist, "DM-60", "DM-60");
   }   else if (selectedmachinery === "CDE Sand Washing Plant") {
    addOption(modelist, "Combo X70", "Combo X70");
   }   else if (selectedmachinery === "Volvo Paver") {
    addOption(modelist, "4361", "4361");
   }   else if (selectedmachinery === "Ingersoll Paver") {
    addOption(modelist, "4360", "4360");
   }   else if (selectedmachinery === "Wirtgen Paver") {
    addOption(modelist, "Vogele S1400", "Vogele S1400");
    addOption(modelist, "SP-64", "SP-64");
   }   else if (selectedmachinery === "Appollo Paver") {
    addOption(modelist, "KLM 1200", "KLM 1200");
   }   else if (selectedmachinery === "Conmet Paver") {
    addOption(modelist, "CE 200", "CE 200");
   }   else if (selectedmachinery === "Kiwi Texture Curing Machine") {
    addOption(modelist, "900", "900");
   }   else if (selectedmachinery === "Sany Concrete Pump") {
    addOption(modelist, "HBT 40C", "HBT 40C");
    addOption(modelist, "Electric", "Electric");
   }   else if (selectedmachinery === "Putzmeister concrete Pump") {
    addOption(modelist, "1407", "1407");
   }   else if (selectedmachinery === "Sany Air Compressor") {
    addOption(modelist, "6 BT Engine", "6 BT Engine");
   }   else if (selectedmachinery === "Ingersoll Air Compressor") {
    addOption(modelist, "B 310", "B 310");
   }   else if (selectedmachinery === "Ingersoll Tower Light") {
    addOption(modelist, "D1105-BG-ET01", "D1105-BG-ET01");
   }   else if (selectedmachinery === "Jackson Diesel Generator Set") {
    addOption(modelist, "125KVA", "125KVA");
    addOption(modelist, "6.25KVA", "6.25KVA");
    addOption(modelist, "15KVA", "15KVA");
    addOption(modelist, "40KVA", "40KVA");
    addOption(modelist, "380KVA", "380KVA");
    addOption(modelist, "25 KVA", "25 KVA");
   }   else if (selectedmachinery === "Koel Diesel Generator Set") {
    addOption(modelist, "30 KVA", "30 KVA");
    addOption(modelist, "25 KVA", "25 KVA");
    addOption(modelist, "15 KVA", "15 KVA");
   }   else if (selectedmachinery === "Powerica Diesel Generator Set") {
    addOption(modelist, "200KVA", "200KVA");
    addOption(modelist, "75KVA", "75KVA");
   }   else if (selectedmachinery === "Kirloskar Diesel Generator Set") {
    addOption(modelist, "200KVA", "200KVA");
    addOption(modelist, "15KVA", "15KVA");
    addOption(modelist, "7.5HP", "7.5HP");
    addOption(modelist, "5HP", "5HP");
   }   else if (selectedmachinery === "Hino Engine Diesel Generator Set") {
    addOption(modelist, "62.5KVA", "62.5KVA");
   }   else if (selectedmachinery === "CAT Diesel Generator Set") {
    addOption(modelist, "500KVA", "500KVA");
   }   else if (selectedmachinery === "Field Marshal Diesel Generator Set") {
    addOption(modelist, "63KVA", "63KVA");
   }   else if (selectedmachinery === "Mahindra Diesel Generator Set") {
    addOption(modelist, "25KVA", "25KVA");
   }   else if (selectedmachinery === "TMC") {
    addOption(modelist, "Eicher Palfinger", "Eicher Palfinger");
   }   else if (selectedmachinery === "Bitumen Bouser") {
    addOption(modelist, "Aadesh Roadtech 3KL/10HP", "Aadesh Roadtech 3KL/10HP");
   }   else if (selectedmachinery === "Service Van") {
    addOption(modelist, "Tata 16.13", "Tata 16.13");
   }   else if (selectedmachinery === "Dewatering Pump") {
    addOption(modelist, "Kirloskar 5HP", "Kirloskar 5HP");
   }   else if (selectedmachinery === "Kerb Lying Machine") {
    addOption(modelist, "Appollo KLM-1200", "Appollo KLM-1200");
   }   else if (selectedmachinery === "Baby Roller") {
    addOption(modelist, "L&T 491 Tandem Compactor", "L&T 491 Tandem Compactor");
   }   else if (selectedmachinery === "JCB Telehandler") {
    addOption(modelist, "JCB 530-110", "JCB 530-110");
   }
   
}

  function addOption(selectElement, value, text) {
    // Create a new option element
    var option = document.createElement("option");

    // Set the value and text of the option
    option.value = value;
    option.text = text;

    // Add the option to the select element
    selectElement.add(option);
  }