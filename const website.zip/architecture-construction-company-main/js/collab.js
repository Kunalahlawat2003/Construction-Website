const slider = document.getElementById('collabs');
  const images = document.querySelectorAll('.collabs-wrapper img');
  
  let counter = 0;
  
  function slide() {
    counter++;
    if (counter === images.length) {
      counter = 0;
    }
  
    slider.style.transition = 'transform 1s ease-in-out';
    slider.style.transform = `translateX(${-counter * 130}px)`; // Adjust the image width as needed
  }
  
  setInterval(slide, 1000);