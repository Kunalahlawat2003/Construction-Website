let currentIndex = 0;
const interval = 3000; // Adjust the interval in milliseconds (e.g., 3000ms = 3 seconds)

function showSlide(index) {
  const slider = document.getElementById('image-slider');
  const totalSlides = slider.children.length;

  if (index < 0) {
    index = totalSlides - 1;
  } else if (index >= totalSlides) {
    index = 0;
  }

  const translateValue = -index * 100 + '%';
  slider.style.transform = 'translateX(' + translateValue + ')';
  currentIndex = index;
}

function nextSlide() {
  showSlide(currentIndex + 1);
}

// Automatically transition to the next slide at the specified interval
setInterval(nextSlide, interval);