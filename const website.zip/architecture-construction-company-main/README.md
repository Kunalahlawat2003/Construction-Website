# Website Preview
   The website has been prepared for an Architecture/Construction company. This website aims to be stylish and dark colours are used. Consists of a single page.
#
# General view
![alt text](https://github.com/sercannaya/architecture-construction-company/blob/main/preview/preview.jpg)
# Detailed view - PC
![alt text](https://github.com/sercannaya/architecture-construction-company/blob/main/preview/preview-pc.png)
# Detailed view - Mobile
![alt text](https://github.com/sercannaya/architecture-construction-company/blob/main/preview/preview-mobile.png)
![alt text](https://github.com/sercannaya/architecture-construction-company/blob/main/preview/preview-mobile-2.png)
